#include <WiFi.h>

const char* ssid = "Pranav";

const char* password = "12345678";

void setup() {
pinMode(16, OUTPUT);
Serial.begin(115200);
WiFi.begin(ssid, password);
Serial.print("Connecting to Wi-Fi");

while (WiFi.status() != WL_CONNECTED) {
  delay(500);
  Serial.print(".");
}

Serial.println("\nConnected!");
Serial.print("ESP32 IP Address: ");
Serial.println(WiFi.localIP());

}
void loop(){
while (WiFi.status() != WL_CONNECTED) {
  digitalWrite(16, LOW);
}
digitalWrite(16, HIGH);
}
