#include <WiFi.h>
#include <WebServer.h>
#include <DHT.h>

#define DHTPIN 16        // DHT11 Data pin
#define DHTTYPE DHT11
#define BUZZER_PIN 27   // Buzzer pin

const char* ssid = "Pranav";
const char* password = "12345678";

DHT dht(DHTPIN, DHTTYPE);
WebServer server(80);

float temperature = 0;
float humidity = 0;

// HTML page with JavaScript for real-time updates
const char htmlPage[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DHT11 Monitor</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100vh;
      background: linear-gradient(135deg, #6e8efb, #a777e3);
      color: white;
    }
    h1 {
      font-size: 2.5rem;
    }
    .data-box {
      margin-top: 20px;
      padding: 20px;
      background: rgba(255,255,255,0.1);
      border-radius: 15px;
      text-align: center;
    }
    .alert {
      margin-top: 20px;
      text-align: center;
      font-size: 2rem;
      font-weight: bold;
      color: red;
    }
  </style>
</head>
<body>
  <h1>🌡 ESP32 DHT11 Monitor</h1>
  <div class="data-box">
    <p>Temperature: <span id="temp">--</span> °C</p>
    <p>Humidity: <span id="hum">--</span> %</p>
  </div>
  <div class="alert" id="alert"></div>
  <script>
    async function fetchData() {
      const response = await fetch('/data');
      const data = await response.json();
      document.getElementById('temp').innerText = data.temperature;
      document.getElementById('hum').innerText = data.humidity;

      if (data.temperature > 27) {
        document.getElementById('alert').innerText = "⚠ ALERT: High Temperature!";
      } else {
        document.getElementById('alert').innerText = "";
      }
    }
    setInterval(fetchData, 2000);
  </script>
</body>
</html>
)rawliteral";

void handleRoot() {
  server.send(200, "text/html", htmlPage);
}

void handleData() {
  String json = "{";
  json += "\"temperature\":" + String(temperature, 1) + ",";
  json += "\"humidity\":" + String(humidity, 1);
  json += "}";
  server.send(200, "application/json", json);
}

void setup() {
  Serial.begin(115200);
  dht.begin();
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  Serial.println("Connecting to WiFi...");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nConnected!");
  Serial.print("ESP32 IP Address: ");
  Serial.println(WiFi.localIP());

  server.on("/", handleRoot);
  server.on("/data", handleData);

  server.begin();
  Serial.println("HTTP server started");
}

void loop() {
  server.handleClient();

  // Read DHT11
  float t = dht.readTemperature();
  float h = dht.readHumidity();
  
  if (!isnan(t) && !isnan(h)) {
    temperature = t;
    humidity = h;
  }

  // Check temperature threshold for buzzer
  if (temperature > 27) {
    digitalWrite(BUZZER_PIN, HIGH);
  } else {
    digitalWrite(BUZZER_PIN, LOW);
  }

  delay(2000);
}
