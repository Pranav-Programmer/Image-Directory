#include <esp_now.h>
#include <WiFi.h>

uint8_t receiverAddress[] = {0xC8, 0xF0, 0x9E, 0x20, 0xCB, 0x84}; // Replace with receiver MAC

typedef struct struct_message {
  char msg[50];
} struct_message;

struct_message myData;
String inputString = "";

// Updated callback to match new esp_now_send_cb_t signature
void onSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  Serial.print("Send Status: ");
  Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Success" : "Fail");
}

void setup() {
  Serial.begin(115200);
  Serial.println("Type your message and press ENTER:");

  WiFi.mode(WIFI_STA);

  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }

  esp_now_register_send_cb(onSent);

  esp_now_peer_info_t peerInfo = {};
  memcpy(peerInfo.peer_addr, receiverAddress, 6);
  peerInfo.channel = 0;
  peerInfo.encrypt = false;

  if (esp_now_add_peer(&peerInfo) != ESP_OK) {
    Serial.println("Failed to add peer");
    return;
  }
}

void loop() {
  if (Serial.available()) {
    inputString = Serial.readStringUntil('\n'); // Read user input
    inputString.trim(); // Remove extra spaces

    if (inputString.length() > 0 && inputString.length() < sizeof(myData.msg)) {
      inputString.toCharArray(myData.msg, sizeof(myData.msg));

      esp_err_t result = esp_now_send(receiverAddress, (uint8_t *)&myData, sizeof(myData));

      if (result == ESP_OK) {
        Serial.print("Sent: ");
        Serial.println(myData.msg);
      } else {
        Serial.println("Error sending message");
      }
    } else {
      Serial.println("Message too long or empty");
    }
  }
}
