#include <WiFi.h>
#include <WebServer.h>

// Your Wi-Fi credentials
const char* ssid = "Pranav";
const char* password = "12345678";

// Create a web server on port 80
WebServer server(80);

void handleRoot() {
  String html = R"rawliteral(
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hello ESP32</title>
    <style>
      body {
        margin: 0;
        font-family: 'Segoe UI', Tahoma, sans-serif;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        background: linear-gradient(45deg, #b87333, #c08040, #d4af37);
        color: #fff;
      }
      .container {
        text-align: center;
      }
      h1 {
        font-size: 5rem;
        margin-bottom: 20px;
      }
      p {
        font-size: 2.2rem;
        opacity: 0.7;
      }
      .badge {
        margin-top: 28px;
        padding: 5px 12px;
        background: #fff;
        color: #d89854;
        border-radius: 30px;
        font-weight: bold;
        font-size: 1.2rem;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <h1>Hindustan Copper Limited</h1>
      <p>Pranav</p>
      <p>Nishant</p>
      <div class="badge">Powered by PSD</div>
    </div>
  </body>
  </html>
  )rawliteral";

  server.send(200, "text/html", html);
}

void setup() {
  Serial.begin(115200);
  Serial.println("Connecting to WiFi...");

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nConnected!");
  Serial.print("ESP32 IP Address: ");
  Serial.println(WiFi.localIP());

  server.on("/", handleRoot);
  server.begin();
  Serial.println("HTTP server started");
}

void loop() {
  server.handleClient();
}
