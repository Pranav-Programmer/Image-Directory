#include <WiFi.h>
#include <WebServer.h>

const char* ssid = "Pranav";
const char* password = "12345678";

#define LED_PIN 16 

WebServer server(80);

const char htmlPage[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hello ESP32</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      height: 100vh;
      background: linear-gradient(135deg, #6e8efb, #a777e3);
      color: #fff;
    }
    h1 {
      font-size: 2.5rem;
      margin-bottom: 15px;
    }
    .btn-container {
      display: flex;
      gap: 20px;
      margin-top: 20px;
    }
    .btn {
      padding: 15px 30px;
      font-size: 1.2rem;
      border: none;
      border-radius: 30px;
      cursor: pointer;
      font-weight: bold;
      transition: all 0.3s ease;
    }
    .on-btn {
      background: #4CAF50;
      color: white;
    }
    .on-btn:hover {
      background: #45a049;
    }
    .off-btn {
      background: #f44336;
      color: white;
    }
    .off-btn:hover {
      background: #da190b;
    }
    .badge {
      margin-top: 30px;
      padding: 10px 20px;
      background: #fff;
      color: #6e8efb;
      border-radius: 30px;
      font-weight: bold;
      font-size: 1rem;
    }
  </style>
</head>
<body>
  <h1>🌐 Hello from ESP32!</h1>
  <p>Control the LED below:</p>
  <div class="btn-container">
    <button class="btn on-btn" onclick="fetch('/on')">Turn ON</button>
    <button class="btn off-btn" onclick="fetch('/off')">Turn OFF</button>
  </div>
  <div class="badge">Powered by ESP32</div>
</body>
</html>
)rawliteral";

void handleRoot() {
  server.send(200, "text/html", htmlPage);
}

void handleLEDOn() {
  digitalWrite(LED_PIN, HIGH);
  server.send(200, "text/plain", "LED is ON");
}

void handleLEDOff() {
  digitalWrite(LED_PIN, LOW);
  server.send(200, "text/plain", "LED is OFF");
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Serial.println("Connecting to WiFi...");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nConnected!");
  Serial.print("ESP32 IP Address: ");
  Serial.println(WiFi.localIP());

  // Define routes
  server.on("/", handleRoot);
  server.on("/on", handleLEDOn);
  server.on("/off", handleLEDOff);

  server.begin();
}

void loop() {
  server.handleClient();
  delay(1000);
}
