#define LED_PIN 16
#define BUTTON_PIN 18
#define BUZZER_PIN 27

int buttonState = 0; 
void setup() {
  pinMode(LED_PIN, OUTPUT);         // Set LED pin as output
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP); // Set button pin as input with pull-up resistor
  Serial.begin(115200);
}

void loop() {
  if (digitalRead(BUTTON_PIN) == LOW){
    digitalWrite (LED_PIN, HIGH);
    digitalWrite(BUZZER_PIN, HIGH);
    Serial.println("LED ON");
  } else {
    digitalWrite (LED_PIN, LOW);
    digitalWrite(BUZZER_PIN, LOW);
    Serial.println("LED OFF");
  }
}
