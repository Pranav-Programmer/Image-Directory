void setup() {
  pinMode(2, OUTPUT);
  pinMode(4, OUTPUT);
  pinMode(16, OUTPUT);
}

void loop() {
 digitalWrite(2, HIGH);
 delay(500);
 digitalWrite(2, LOW);
 delay(500);
 digitalWrite(4, HIGH);
 delay(500);
 digitalWrite(4, LOW);
 delay(500);
 digitalWrite(16, HIGH);
 delay(500);
 digitalWrite(16, LOW);
 delay(500);
}
