#define BTN BTN_USER
#define HEAT_LEFT 2
#define HEAT_RIGHT 3
#define TEMP_SENS A7

void setup() {

  // put your setup code here, to run once:

  Serial.begin(9600);


  pinMode(HEAT_LEFT, OUTPUT);
  pinMode(HEAT_RIGHT, OUTPUT);
  pinMode(BTN, INPUT);
  pinMode(TEMP_SENS, INPUT);

}

int SCENE = -1;
bool btn_state = 0;

void loop() {

  // PART 1: read the USER BUTTON and change SCENE when pressed
  if (btn_state == 0) {
    if (digitalRead(BTN) == 0) {
      btn_state = 1;
      SCENE++;
      if (SCENE > 2) {
        SCENE = -1;
      }
    }
  } else {
    if (digitalRead(BTN) == 1) {
      btn_state = 0;
    }
  }

  // PART 2: depending on the SCENE value, trigger one or both (or none) heating circuits
  if (SCENE == -1) {
    digitalWrite(HEAT_LEFT, LOW);
    digitalWrite(HEAT_RIGHT, LOW);
  } else if (SCENE == 0) {
    digitalWrite(HEAT_LEFT, HIGH);
    digitalWrite(HEAT_RIGHT, LOW);
  } else if (SCENE == 1) {
    digitalWrite(HEAT_LEFT, LOW);
    digitalWrite(HEAT_RIGHT, HIGH);
  } else if (SCENE == 2) {
    digitalWrite(HEAT_LEFT, HIGH);
    digitalWrite(HEAT_RIGHT, HIGH);
  }

  // PART 3: print on the serial, with a special format for the plotter!
  Serial.print("MIN:");
  Serial.print(300);
  Serial.print(",");

  Serial.print("MAX:");
  Serial.print(650);
  Serial.print(",");

  Serial.print("TEMP:");
  Serial.println(analogRead(TEMP_SENS));

  delay(250);

}
