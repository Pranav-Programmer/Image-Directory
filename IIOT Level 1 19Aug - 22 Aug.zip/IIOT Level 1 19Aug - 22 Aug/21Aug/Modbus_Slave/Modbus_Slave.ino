//Modbus Slave code

#include <SPI.h>
#include <Ethernet.h>
#include <ArduinoRS485.h>
#include <ArduinoModbus.h>

#define BTN BTN_USER
#define HEAT_LEFT 2
#define HEAT_RIGHT 3
#define TEMP_SENS A7

int SCENE = -1;
bool btn_state = 0;

byte mac[] = { 0xA8, 0x61, 0x0A, 0x50, 0xA9, 0xCC };  //replace with your controller MAC 
IPAddress ip(192, 168, 1, 175); // Slave IP

EthernetServer ethServer(502);
ModbusTCPServer modbusTCPServer;

void setup() {
  Serial.begin(9600);

  pinMode(HEAT_LEFT, OUTPUT);
  pinMode(HEAT_RIGHT, OUTPUT);
  pinMode(BTN, INPUT);
  pinMode(TEMP_SENS, INPUT);

  Ethernet.begin(mac, ip);
  ethServer.begin();

  if (!modbusTCPServer.begin()) {
    Serial.println("Failed to start Modbus TCP Server!");
    while (1);
  }

  modbusTCPServer.configureHoldingRegisters(0x00, 1);
}

void loop() {
  EthernetClient client = ethServer.available();

  if (client) {
    modbusTCPServer.accept(client);

    while (client.connected()) {
      modbusTCPServer.poll();

      // Button controls scenes
      if (btn_state == 0 && digitalRead(BTN) == 0) {
        btn_state = 1;
        SCENE++;
        if (SCENE > 2) SCENE = -1;
      } else if (digitalRead(BTN) == 1) {
        btn_state = 0;
      }

      // Scene controls heaters
      digitalWrite(HEAT_LEFT, (SCENE == 0 || SCENE == 2) ? HIGH : LOW);
      digitalWrite(HEAT_RIGHT, (SCENE == 1 || SCENE == 2) ? HIGH : LOW);

      // Read temp and update holding register
      int temp = analogRead(TEMP_SENS);
      modbusTCPServer.holdingRegisterWrite(0x00, temp);

      delay(250);  // update every 250ms
    }

    client.stop();
  }
}
