//Modbus Master code 

#include <SPI.h>
#include <Ethernet.h>
#include <ArduinoRS485.h>
#include <ArduinoModbus.h>

#define BTN BTN_USER

byte mac[] = { 0xA8, 0x61, 0x0A, 0x50, 0xA3, 0x1C };  // Master MAC
IPAddress ip(192, 168, 1, 177);                      // Master IP
IPAddress slaveIP(192, 168, 1, 175);                 // Slave IP

EthernetClient ethClient;
ModbusTCPClient modbusTCPClient(ethClient);

bool buttonPressed = false;

// Approximate linear conversion from your table: (348, 15°C) to (399, 20°C)
float adcToCelsius(int adcValue) {
  float m = 5.0 / 51.0;
  float b = 15.0 - (m * 348.0);
  return (m * adcValue) + b;
}

void setup() {
  pinMode(BTN, INPUT);
  Serial.begin(9600);
  while (!Serial); // Wait for Serial on USB boards

  Ethernet.begin(mac, ip);
  delay(1000);

  Serial.println("Waiting for button press to read temperature...");
}

void loop() {
  // Reconnect if not connected
  if (!modbusTCPClient.connected()) {
    Serial.println("Connecting to slave...");
    if (!modbusTCPClient.begin(slaveIP, 502)) {
      Serial.println("Connection failed.");
      delay(1000);
      return;
    }
  }

  // Check for button press
  if (digitalRead(BTN) == LOW && !buttonPressed) {
    buttonPressed = true;

    Serial.println("Requesting temperature...");
    if (modbusTCPClient.requestFrom(HOLDING_REGISTERS, 0x00, 1)) {
      int raw = modbusTCPClient.read();
      float tempC = adcToCelsius(raw);

      Serial.print("Raw ADC Value: ");
      Serial.print(raw);
      Serial.print(" → Estimated Temperature: ");
      Serial.print(tempC, 1);
      Serial.println(" °C");
    } else {
      Serial.println("Modbus read failed.");
    }
  }

  // Reset button state on release
  if (digitalRead(BTN) == HIGH && buttonPressed) {
    buttonPressed = false;
  }

  delay(50); // Debounce
}
