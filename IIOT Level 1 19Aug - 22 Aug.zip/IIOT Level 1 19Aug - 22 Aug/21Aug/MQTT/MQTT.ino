#include <WiFi.h>
#include <MQTTClient.h>

const char* SSID = "Pranav";
const char* PASSWORD = "12345678";
const char* BROKER = "10.58.57.62";

#define CLIENT_ID "ESP32-001"
#define PUB_TOPIC "esp32-001/send"
#define SUB_TOPIC "esp32-001/receive"
#define PUBLISH_INTERVAL 5000

WiFiClient net;
MQTTClient client;

unsigned long lastSent = 0;

void messageReceived(String &topic, String &payload) {
Serial.println("Incoming: " + topic + " - " + payload);
}

void connectWiFi() {
WiFi.begin(SSID, PASSWORD);
Serial.print("Connecting to WiFi");
while (WiFi.status() != WL_CONNECTED) {
Serial.print(".");
delay(500);
}
Serial.println(" connected");
}

void connectMQTT() {
client.begin(BROKER, net);
client.onMessage(messageReceived); // Use clearly defined handler

Serial.print("Connecting to MQTT");
while (!client.connect(CLIENT_ID)) {
Serial.print(".");
delay(500);
}
Serial.println(" connected");

client.subscribe(SUB_TOPIC);
}

void setup() {
Serial.begin(9600);
connectWiFi();
connectMQTT();
}

void loop() {
client.loop();

if (millis() - lastSent > PUBLISH_INTERVAL) {
client.publish(PUB_TOPIC, "Hello from ESP32");
Serial.println("Published: Hello from ESP32");
lastSent = millis();
}
}
