#include <WiFi.h>
#include "ThingSpeak.h"
#include <DHT.h>

// ---------- Wi-Fi Details ----------
char ssid[] = "BFSIL2";      // Replace with your Wi-Fi SSID
char pass[] = "123456789";      // Replace with your Wi-Fi Password
//------------------------------------

// ---------- ThingSpeak Settings ----------
unsigned long myChannelField = 3042736;  // Replace with your ThingSpeak Channel ID (no quotes)
const int Temp = 1;          // Field 1 for Temperature
const int Humidity = 2;      // Field 2 for Humidity
const char *myWriteAPIKey = "61J8REAZGMNB0SYO"; // Replace with your ThingSpeak Write API Key
//------------------------------------------

// ---------- DHT Sensor Settings ----------
#define DHTPIN 16         // GPIO pin where DHT11 is connected
#define DHTTYPE DHT11     // DHT11 Sensor
DHT dht(DHTPIN, DHTTYPE);
//------------------------------------------

// ---------- Globals ----------
WiFiClient client;
float humidity;
float temp;
//----------------------------------

void setup() {
  Serial.begin(115200);
  dht.begin();
  WiFi.mode(WIFI_STA);
  ThingSpeak.begin(client); // Initialize ThingSpeak
}

void loop() {
  // Connect to Wi-Fi if not connected
  if (WiFi.status() != WL_CONNECTED) {
    Serial.print("Connecting to WiFi: ");
    Serial.println(ssid);
    while (WiFi.status() != WL_CONNECTED) {
      WiFi.begin(ssid, pass);
      Serial.print(".");
      delay(5000);
    }
    Serial.println("\nWiFi connected.");
  }

  // Read from DHT Sensor
  humidity = dht.readHumidity();
  temp = dht.readTemperature();

  // Check if readings are valid
  if (isnan(humidity) || isnan(temp)) {
    Serial.println("Failed to read from DHT sensor!");
    return;
  }

  // Print readings to Serial Monitor
  Serial.print("Temperature: ");
  Serial.print(temp);
  Serial.print(" °C, Humidity: ");
  Serial.print(humidity);
  Serial.println(" %");

  // Set fields for ThingSpeak
  ThingSpeak.setField(Temp, temp);
  ThingSpeak.setField(Humidity, humidity);

  // Write both fields at once
  int statusCode = ThingSpeak.writeFields(myChannelField, myWriteAPIKey);
  if (statusCode == 200) {
    Serial.println("ThingSpeak update successful.");
  } else {
    Serial.print("ThingSpeak update failed. HTTP error code: ");
    Serial.println(statusCode);
  }

  delay(20000); // Wait 20 seconds (minimum 15 sec for free accounts)
}
